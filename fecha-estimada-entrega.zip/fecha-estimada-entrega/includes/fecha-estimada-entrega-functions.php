<?php
// Función para calcular la fecha estimada de entrega
function calcular_fecha_estimacion_entrega() {
    // Obtener la configuración
    $options = get_option('fecha_estimada_entrega_options');
    $dias_entrega = isset($options['delivery_days']) ? intval($options['delivery_days']) : 2;
    $emoji_entrega = isset($options['delivery_emoji']) ? esc_html($options['delivery_emoji']) : '📦';
    $formato_fecha = isset($options['date_format']) ? esc_html($options['date_format']) : 'l, d F Y';

    // Obtener la fecha actual
    $fecha_actual = current_time('timestamp');

    // Calcular la fecha de entrega inicial
    $fecha_entrega = strtotime('+' . $dias_entrega . ' days', $fecha_actual);

    // Obtener el día de la semana de la fecha actual (0=Domingo, 1=Lunes, ..., 6=Sábado)
    $dia_semana_actual = date('w', $fecha_actual);

    // Ajustar la fecha de entrega si la visualización es en viernes, sábado o domingo
    if ($dia_semana_actual == 5) {
        // Viernes: la entrega es el próximo martes
        $fecha_entrega = strtotime('next Tuesday', $fecha_actual);
    } elseif ($dia_semana_actual == 6) {
        // Sábado: la entrega es el próximo martes
        $fecha_entrega = strtotime('next Tuesday', $fecha_actual);
    } elseif ($dia_semana_actual == 0) {
        // Domingo: la entrega es el próximo martes
        $fecha_entrega = strtotime('next Tuesday', $fecha_actual);
    }

    // Formatear la fecha de entrega con el formato proporcionado por el usuario
    $fecha_entrega_formateada = date_i18n($formato_fecha, $fecha_entrega);

    // Crear el HTML para la fecha de entrega con estilos y enlace a las condiciones del envío
    $html_fecha_entrega = '
        <p class="estimacion-entrega" style="color: #27AE60; font-weight: bold; font-size: 1.2em; text-align: center; padding: 10px; border: 2px dashed #27AE60; border-radius: 10px; background-color: #EAF2E3;">
            ' . $emoji_entrega . ' ' . __('Fecha estimada de llegada:', 'fecha-estimada-entrega') . ' ' . esc_html($fecha_entrega_formateada) . '
        </p>
        <p class="condiciones-envio" style="text-align: center; font-size: 0.8em;">
            <a href="#" style="color: #27AE60; text-decoration: underline;">' . __('Condiciones del envío', 'fecha-estimada-entrega') . '</a>
        </p>
    ';

    // Devolver el HTML
    return $html_fecha_entrega;
}

// Función para el shortcode
function shortcode_fecha_estimacion_entrega() {
    return calcular_fecha_estimacion_entrega();
}

// Registrar el shortcode
add_shortcode('fecha_estimacion_entrega', 'shortcode_fecha_estimacion_entrega');